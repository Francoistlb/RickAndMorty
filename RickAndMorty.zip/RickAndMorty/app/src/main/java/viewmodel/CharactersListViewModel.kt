package com.votreapp.viewmodel

import android.util.Log
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import model.Character
import model.CharacterReponse
import network.RetrofitInstance
import kotlinx.coroutines.launch
import retrofit2.Response

class CharactersListViewModel : ViewModel() {

    // MutableLiveData pour stocker les personnages
    private val _characters = MutableLiveData<List<Character>>()
    val characters: LiveData<List<Character>> get() = _characters

    // MutableLiveData pour gérer les erreurs
    private val _errorMessage = MutableLiveData<String?>()
    val errorMessage: LiveData<String?> get() = _errorMessage

    // Fonction pour récupérer tous les personnages
    fun fetchAllCharacters() {
        viewModelScope.launch {
            try {
                val response: Response<CharacterReponse> = RetrofitInstance.retrofitService.getCharacters(1)
                if (response.isSuccessful) {
                    _characters.value = (response.body()?.results ?: emptyList())
                } else {
                    _errorMessage.value = "Erreur: ${response.message()}"
                }
            } catch (e: Exception) {
                _errorMessage.value = "Une erreur s'est produite: ${e.message}"
            }

            try {
                val response = RetrofitInstance.retrofitService.getCharacters(1)
                Log.d("NetworkTest", "Response: ${response.body()}")
            } catch (e: Exception) {
                Log.e("NetworkTest", "Error: ${e.message}")
            }
        }
    }
}
