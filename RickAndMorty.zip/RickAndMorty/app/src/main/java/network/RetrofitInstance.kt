package network

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
object RetrofitInstance {

    private const val BASE_URL = "https://rickandmortyapi.com/api/"  // Remplacez par l'URL de base correcte

    // Création de l'instance Retrofit avec GsonConverterFactory
    private val retrofit by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)  // URL de base de l'API
            .addConverterFactory(GsonConverterFactory.create())  // Utiliser Gson comme convertisseur JSON
            .build()
    }

    // Service API pour accéder aux méthodes définies dans l'interface
    val retrofitService: RickAndMortyApiService by lazy {
        retrofit.create(RickAndMortyApiService::class.java)  // Créer le service API
    }
}
