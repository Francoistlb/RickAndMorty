package fr.epsi.talaban.rickandmorty

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack

import androidx.compose.material3.Button
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton

import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier

import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import coil.compose.rememberAsyncImagePainter


class CharacterDetailsActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Récupération des valeurs

        val image = intent.getStringExtra("image") ?: ""
        val name = intent.getStringExtra("name") ?: "Inconnu"
        val statut = intent.getStringExtra("statut") ?: "Inconnu"
        val espece = intent.getStringExtra("espece") ?: "Inconnu"
        val type = intent.getStringExtra("type") ?: "Inconnu"
        val genre = intent.getStringExtra("genre") ?: "Inconnu"
        val origine = intent.getStringExtra("origine") ?: "Inconnu"
        val localisation = intent.getStringExtra("localisation") ?: "Inconnu"

        setContent {
            CharacterDetailScreen(
                image,
                name,
                statut,
                espece,
                type,
                genre,
                origine,
                localisation)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CharacterDetailScreen(

    // Paramètres de la fonction

    image : String,
    name: String,
    statut: String,
    espece: String,
    type: String,
    genre: String,
    origine : String,
    localisation : String

) {
    Column(modifier = Modifier.fillMaxSize()) {
        val context = LocalContext.current

        TopAppBar(
            title = { Text(name) },
            navigationIcon = {
                IconButton(onClick = {
                    // Navigation vers l'écran de la liste des personnages
                    val intent = Intent(context, CharactersListActivity::class.java)
                    context.startActivity(intent)
                }) {
                    Icon(Icons.Filled.ArrowBack, contentDescription = "Menu")
                }
            },

        )

        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            verticalAlignment  = Alignment.Top,
            horizontalArrangement  = Arrangement.Start
        ) {

            Image(
                painter = rememberAsyncImagePainter(image),
                contentDescription = "Character image",
                modifier = Modifier
                    .size(150.dp)
                    .padding(end = 16.dp)
            )

            // Affichage des informations
            Column(
                verticalArrangement = Arrangement.Top,
                horizontalAlignment = Alignment.Start
            ) {
                Text("Statut: $statut")
                Text("Espèce: $espece")
                Text("Type: $type")
                Text("Genre: $genre")
                Text("Origine: $origine")
                Text("Localisation: $localisation")
            }
        }
    }
}



