package model

import com.google.gson.annotations.SerializedName

// Modèle pour un personnage

data class Character(
    val id: Int,
    val name: String,
    val status : String,
    val type : String,
    val gender : String,
    val species: String,
    val image: String,


    @SerializedName("origin") val originName: Origin,
    @SerializedName("location") val locationName: Location

    // @SerialName("full_name") val name: String, si le nom des 2 infos sont différentes
    )

data class Origin(
    val name: String
)

data class Location(
    val name: String
)