package model


import com.google.gson.annotations.SerializedName


data class CharacterReponse(

    // Liste de personnages avec les champs nécessaires
    val results: List<Character>

)
